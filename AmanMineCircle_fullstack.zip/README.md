# AmanMineCircle — full-stack

AmanMineCircle is now a real server-backed site: GitHub OAuth, PostgreSQL persistence, profiles, scores, leaderboard, anonymous chat, notifications, live message, and owner moderation.

## Local setup

Requires Node.js 18+ and PostgreSQL.

1. Create a PostgreSQL database.
2. Copy `.env.example` to `.env` and fill in the values.
3. Create a GitHub OAuth App. Local callback URL: `http://localhost:3000/auth/github/callback`.
4. Set `ADMIN_GITHUB_ID` to your numeric GitHub user ID so the owner-only live-message and moderation APIs work.
5. Run `npm install` then `npm start`.
6. Open `http://localhost:3000`.

The server automatically creates the database tables from `schema.sql` on startup.

## Production / Render

`render.yaml` creates a Node web service and managed PostgreSQL database. Push this folder to a GitHub repository, create a Render Blueprint from that repo, and fill the prompted secret values. Set `BASE_URL` to the exact deployed HTTPS URL, then set the GitHub OAuth callback to `<BASE_URL>/auth/github/callback`.

Render web services need to listen on `0.0.0.0` and the app does this automatically. The database is persistent; do not store user data in local files.

## Security notes

- GitHub Client Secret is server-only.
- Session tokens are stored hashed in PostgreSQL and sent as HttpOnly cookies.
- OAuth state is single-use and expires after 10 minutes.
- Chat messages are length-limited and owner moderation is server-side.
- Never commit `.env` or secrets to Git.
