const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');
const { Pool } = require('pg');

const PORT = Number(process.env.PORT || 3000);
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const CLIENT_ID = process.env.GITHUB_CLIENT_ID;
const CLIENT_SECRET = process.env.GITHUB_CLIENT_SECRET;
const DATABASE_URL = process.env.DATABASE_URL;
const ADMIN_GITHUB_ID = process.env.ADMIN_GITHUB_ID || '';
if (!DATABASE_URL) console.warn('DATABASE_URL is not set. The app needs PostgreSQL.');
const pool = DATABASE_URL ? new Pool({connectionString: DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? {rejectUnauthorized:false} : undefined, max: 10}) : null;
const root = __dirname;
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml'};
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const token = bytes => crypto.randomBytes(bytes).toString('hex');
const isProd = process.env.NODE_ENV === 'production';

async function db(sql, params=[]) { if (!pool) throw new Error('Database is not configured'); return pool.query(sql, params); }
async function initDb(){ const sql=fs.readFileSync(path.join(root,'schema.sql'),'utf8'); for(const statement of sql.split(';').map(s=>s.trim()).filter(Boolean)) await db(statement); }
function json(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));}
function redirect(res,location,headers={}){res.writeHead(302,{Location:location,...headers});res.end();}
function cookies(req){return Object.fromEntries((req.headers.cookie||'').split(';').filter(Boolean).map(x=>{const [k,...v]=x.trim().split('=');return [k,decodeURIComponent(v.join('='))]}));}
function sessionCookie(value,maxAge=604800){return `amic_session=${encodeURIComponent(value)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${isProd?'; Secure':''}`;}
async function currentUser(req){const sid=cookies(req).amic_session;if(!sid)return null;const r=await db(`SELECT u.*, s.expires_at FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW()`,[hash(sid)]);return r.rows[0]||null;}
function publicUser(u){if(!u)return null;return {id:u.id,github_id:u.github_id,login:u.login,name:u.name,avatar:u.avatar,html_url:u.html_url,bio:u.bio,public_repos:u.public_repos,points:Number(u.points),games:u.games,wins:u.wins,quiz:u.quiz,isAdmin:String(u.github_id)===ADMIN_GITHUB_ID};}
async function body(req){return new Promise((resolve,reject)=>{let data='';req.on('data',c=>{data+=c;if(data.length>100000)reject(new Error('Body too large'))});req.on('end',()=>{try{resolve(data?JSON.parse(data):{})}catch{reject(new Error('Invalid JSON'))}});req.on('error',reject)})}
async function githubToken(code){const r=await fetch('https://github.com/login/oauth/access_token',{method:'POST',headers:{Accept:'application/json','Content-Type':'application/json'},body:JSON.stringify({client_id:CLIENT_ID,client_secret:CLIENT_SECRET,code})});return r.json();}
async function githubUser(accessToken){const r=await fetch('https://api.github.com/user',{headers:{Authorization:`Bearer ${accessToken}`,Accept:'application/vnd.github+json','User-Agent':'AmanMineCircle'}});return r.json();}
async function githubEmails(accessToken){const r=await fetch('https://api.github.com/user/emails',{headers:{Authorization:`Bearer ${accessToken}`,Accept:'application/vnd.github+json','User-Agent':'AmanMineCircle'}});return r.ok?r.json():[];}
function requireAuth(user,res){if(!user){json(res,401,{error:'Sign in with GitHub first'});return false}return true;}
function requireAdmin(user,res){if(!user||String(user.github_id)!==ADMIN_GITHUB_ID){json(res,403,{error:'Admin only'});return false}return true;}

const server=http.createServer(async(req,res)=>{
 try{
  const u=new URL(req.url,BASE_URL);
  if(u.pathname==='/health') return json(res,200,{ok:true});
  if(u.pathname==='/auth/github'){
   if(!CLIENT_ID||!CLIENT_SECRET)return redirect(res,'/?auth_error=github_not_configured');
   const state=token(24); await db('INSERT INTO oauth_states(state_hash) VALUES($1)',[hash(state)]);
   const callback=`${BASE_URL}/auth/github/callback`;
   const q=new URLSearchParams({client_id:CLIENT_ID,redirect_uri:callback,state,scope:'read:user user:email'});
   return redirect(res,`https://github.com/login/oauth/authorize?${q}`);
  }
  if(u.pathname==='/auth/github/callback'){
   const state=u.searchParams.get('state'),code=u.searchParams.get('code');
   if(!state||!code)return redirect(res,'/?auth_error=invalid_callback');
   const st=await db('DELETE FROM oauth_states WHERE state_hash=$1 AND created_at>NOW()-INTERVAL \'10 minutes\' RETURNING state_hash',[hash(state)]);
   if(!st.rowCount)return redirect(res,'/?auth_error=invalid_state');
   const access=await githubToken(code); if(!access.access_token)return redirect(res,'/?auth_error=github_token_failed');
   const gh=await githubUser(access.access_token); if(!gh.id)return redirect(res,'/?auth_error=github_profile_failed');
   await githubEmails(access.access_token);
   const existing=await db('SELECT id FROM users WHERE github_id=$1',[gh.id]);
   let userId;
   if(existing.rowCount){const r=await db(`UPDATE users SET login=$1,name=$2,avatar=$3,html_url=$4,bio=$5,public_repos=$6,updated_at=NOW() WHERE github_id=$7 RETURNING id`,[gh.login,gh.name||gh.login,gh.avatar_url,gh.html_url,gh.bio||'',gh.public_repos||0,gh.id]);userId=r.rows[0].id;}
   else {const r=await db(`INSERT INTO users(github_id,login,name,avatar,html_url,bio,public_repos) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,[gh.id,gh.login,gh.name||gh.login,gh.avatar_url,gh.html_url,gh.bio||'',gh.public_repos||0]);userId=r.rows[0].id;await db('INSERT INTO notifications(user_id,body) VALUES($1,$2)',[userId,'Welcome to AmanMineCircle 💗']);}
   const sid=token(32);await db('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES($1,$2,NOW()+INTERVAL \'7 days\')',[hash(sid),userId]);
   return redirect(res,'/',{'Set-Cookie':sessionCookie(sid)});
  }
  if(u.pathname==='/auth/logout'){const sid=cookies(req).amic_session;if(sid)await db('DELETE FROM sessions WHERE token_hash=$1',[hash(sid)]);return redirect(res,'/',{'Set-Cookie':sessionCookie('',0)});}
  const user=await currentUser(req);
  if(req.method==='GET'&&u.pathname==='/api/me')return json(res,200,{user:publicUser(user)});
  if(req.method==='GET'&&u.pathname==='/api/bootstrap'){
   const [chat,leaders,settings,notes]=await Promise.all([
    db(`SELECT id,anonymous_name AS name,avatar,body AS text,created_at FROM chat_messages WHERE hidden=FALSE ORDER BY id DESC LIMIT 100`),
    db(`SELECT login AS username,avatar,points,games,wins,quiz FROM users ORDER BY points DESC, wins DESC LIMIT 50`),
    db(`SELECT value FROM site_settings WHERE key='live_message'`),
    user?db(`SELECT body FROM notifications WHERE user_id=$1 ORDER BY id DESC LIMIT 20`,[user.id]):Promise.resolve({rows:[]})
   ]);
   return json(res,200,{user:publicUser(user),live:settings.rows[0]?.value||'',chat:chat.rows.reverse(),leaderboard:leaders.rows.map(x=>({...x,points:Number(x.points)})),notifications:notes.rows.map(x=>x.body)});
  }
  if(req.method==='POST'&&u.pathname==='/api/chat'){
   if(!requireAuth(user,res))return; const b=await body(req),text=String(b.text||'').trim();if(text.length<1||text.length>500)return json(res,400,{error:'Message must be 1–500 characters'});
   const anonymousName='Anonymous '+({'🐱':'Cat','🐶':'Dog','🐰':'Bunny','🦊':'Fox','🐼':'Panda','🐻':'Bear','🐯':'Tiger','🐨':'Koala','🐸':'Frog','🐵':'Monkey','🦄':'Unicorn','🐹':'Hamster'}[b.avatar]||'Friend');
   const r=await db(`INSERT INTO chat_messages(user_id,anonymous_name,avatar,body) VALUES($1,$2,$3,$4) RETURNING id,anonymous_name AS name,avatar,body AS text,created_at`,[user.id,anonymousName,String(b.avatar||'🐱'),text]);return json(res,201,{message:r.rows[0]});
  }
  if(req.method==='POST'&&u.pathname==='/api/stats'){
   if(!requireAuth(user,res))return;const b=await body(req),games=Math.max(0,Math.min(1,Number(b.games)||0)),wins=Math.max(0,Math.min(1,Number(b.wins)||0)),quiz=Math.max(0,Math.min(10,Number(b.quiz)||0)),points=Math.max(0,Math.min(100,Number(b.points)||0));
   const r=await db(`UPDATE users SET games=games+$1,wins=wins+$2,quiz=$3,points=points+$4,updated_at=NOW() WHERE id=$5 RETURNING *`,[games,wins,quiz,points,user.id]);return json(res,200,{user:publicUser(r.rows[0])});
  }
  if(req.method==='POST'&&u.pathname==='/api/avatar'){
   if(!requireAuth(user,res))return;const allowed=['🐱','🐶','🐰','🦊','🐼','🐻','🐯','🐨','🐸','🐵','🦄','🐹'];const a=String((await body(req)).avatar||'');if(!allowed.includes(a))return json(res,400,{error:'Invalid avatar'});const r=await db('UPDATE users SET avatar=$1,updated_at=NOW() WHERE id=$2 RETURNING *',[a,user.id]);return json(res,200,{user:publicUser(r.rows[0])});
  }
  if(req.method==='POST'&&u.pathname==='/api/live'){
   if(!requireAdmin(user,res))return;const text=String((await body(req)).text||'').trim().slice(0,300);await db(`INSERT INTO site_settings(key,value) VALUES('live_message',$1) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value`,[text]);return json(res,200,{live:text});
  }
  if(req.method==='GET'&&u.pathname==='/api/admin/messages'){
   if(!requireAdmin(user,res))return;const r=await db(`SELECT id,anonymous_name AS name,avatar,body AS text,hidden,created_at FROM chat_messages ORDER BY id DESC LIMIT 200`);return json(res,200,{messages:r.rows});
  }
  if(req.method==='POST'&&u.pathname==='/api/admin/messages/hide'){
   if(!requireAdmin(user,res))return;const id=Number((await body(req)).id);await db('UPDATE chat_messages SET hidden=TRUE WHERE id=$1',[id]);return json(res,200,{ok:true});
  }
  let file=u.pathname==='/'?'/index.html':u.pathname;file=path.normalize(file).replace(/^([.][.][\\/])+/, '');const full=path.join(root,file);if(!full.startsWith(root)||!fs.existsSync(full)||fs.statSync(full).isDirectory())return json(res,404,{error:'Not found'});res.writeHead(200,{'Content-Type':mime[path.extname(full)]||'application/octet-stream'});fs.createReadStream(full).pipe(res);
 }catch(e){console.error(e);json(res,500,{error:'Server error'});}
});
(async()=>{try{if(pool){await initDb();await db('DELETE FROM sessions WHERE expires_at<NOW()');console.log('Database ready');}server.listen(PORT,'0.0.0.0',()=>console.log(`AmanMineCircle running at ${BASE_URL}`));}catch(e){console.error(e);process.exit(1)}})();
