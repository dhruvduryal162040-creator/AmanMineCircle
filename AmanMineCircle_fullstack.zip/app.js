const state={
 page:"home", user:{name:"Aman",username:"Ammuu",avatar:"🐱",points:0,games:0,wins:0,quiz:0},
 live:"Hehehe… I don't even know myself sometimes 😂",
 leaderboard:[
  {username:"Ammuu",avatar:"🐱",points:0,games:0,wins:0,quiz:0},
  {username:"PinkPanda",avatar:"🐼",points:42,games:18,wins:12,quiz:8},
  {username:"Foxie",avatar:"🦊",points:36,games:16,wins:10,quiz:7},
  {username:"Bunny",avatar:"🐰",points:29,games:12,wins:8,quiz:6},
  {username:"Koala",avatar:"🐨",points:21,games:10,wins:6,quiz:5}
 ],
 notifications:["Welcome to AmanMineCircle 💗","Your profile is ready!"],
 chat:[
  {a:"🐼",name:"Anonymous Panda",text:"This place is actually cute 😂"},
  {a:"🦊",name:"Anonymous Fox",text:"Who is ready for the next quiz?"},
  {a:"🐰",name:"Anonymous Bunny",text:"I am NOT losing the leaderboard 😭"}
 ],
 avatars:["🐱","🐶","🐰","🦊","🐼","🐻","🐯","🐨","🐸","🐵","🦄","🐹"]
};
let game=null,quiz=null;
let authUser=null;

function app(){
 document.querySelector("#app").innerHTML=pages[state.page]||pages.home; bind(); updateAuthUI();
}
const nav=p=>{state.page=p;app();scrollTo(0,0)}
const pages={
home:()=>`<section class="hero"><img src="logo.svg"><h1>AmanMineCircle</h1><p>Welcome to my little world 💗<br><b>“I just want to have fun! These days have been a little lonely, so I made this place to keep my friends active, have fun, and enjoy together.”</b></p><div class="live">😂 <b>Live:</b> ${state.live}</div></section><div class="grid">
${card("👤","ABOUT AMAN","Get to know Ammuu","about")}${card("🎮","GAMES","Play mini-games and earn points","games")}${card("🧠","QUIZ","10-question challenge","quiz")}${card("🏆","LEADERBOARD","See TOP 1, TOP 2, TOP 3…","leaderboard")}${card("💬","ANONYMOUS CHAT","Talk and reply without public identities","chat")}
</div><div class="footer">Made with 💗 for friends · AmanMineCircle</div>`,
about:()=>`<section><div class="profile-head"><div class="avatar">${state.user.avatar}</div><div><span class="pill">@${state.user.username}</span><h1>Aman</h1></div></div><div class="card"><h2>About me</h2><p>I just want to have fun! These days have been a little lonely, so I made this place to keep my friends active, have fun, and enjoy together. 💗</p><h3>😂 Fun fact</h3><p>Hehehe… I don't even know myself sometimes. My personality keeps changing 😂. People who don't know me think I'm dangerous, but I'm actually just a childish person.</p><h3>💗 Things I like</h3><p>🎮 Every kind of game · 🎵 Mixing music · 🎬 All types of movies</p></div><div class="card"><h2>📌 My socials</h2><p class="muted">Your Instagram and Snapchat links can be added from the owner dashboard.</p></div><div class="card"><h2>😂 Live funny section</h2><p class="live">${state.live}</p><button class="primary" id="editLive">Edit live message</button></div></section>`,
games:()=>`<section><h1>🎮 Mini-Games</h1><p class="muted">Every match lasts 1:30. Each win = 1 game point. 10% goes to the global leaderboard.</p><div class="grid">${card("⚡","Reaction Rush","Tap the target as fast as you can","startGame","reaction")}${card("🎯","Moving Target","Hit the moving target","startGame","moving")}${card("🧠","Memory Tiles","Remember the pattern","startGame","memory")}${card("🚧","Dodge","Avoid the obstacles","startGame","dodge")}${card("🚫","Don't Click It","Find what is safe","startGame","dont")}</div><div id="gameArea"></div></section>`,
quiz:()=>`<section><h1>🧠 Quiz</h1><p class="muted">10 questions. Each question has up to 3 minutes. Correct = 1 point.</p><div class="quizbox"><h2>Ready?</h2><p>Show how well you know Aman and take on the challenge.</p><button class="primary" id="startQuiz">Start 10-question quiz</button><p class="muted">Maximum time: 30 minutes · 10% of your score contributes to the leaderboard.</p></div><div id="quizArea"></div></section>`,
leaderboard:()=>`<section><h1>🏆 Global Leaderboard</h1><p class="muted">One leaderboard for everyone. TOP 1, TOP 2, TOP 3…</p>${[...state.leaderboard].sort((a,b)=>b.points-a.points).map((u,i)=>`<button class="lbrow ${i<3?"top":""}" data-profile="${u.username}"><span class="rank">${medal(i)}</span><span class="avatar sm">${u.avatar}</span><span><b>${u.username}</b><small class="muted"> · ${u.games} games · ${u.wins} wins</small></span><span class="score">${u.points} ⭐</span></button>`).join("")}</section>`,
chat:()=>`<section class="chat"><h1>💬 Anonymous Chat</h1><div class="notice">You are anonymous to other visitors. The site owner can manage the community and handle reports.</div><div id="messages">${state.chat.map(m=>`<div class="message"><span class="avatar sm">${m.a}</span> <b>${m.name}</b><p>${escapeHtml(m.text)}</p><button class="secondary reply" data-name="${m.name}">↩ Reply</button></div>`).join("")}</div><div class="composer"><input id="chatInput" placeholder="Say something…"><button class="primary" id="sendChat">Send</button></div></section>`,
profile:()=>`<section><h1>👤 My Profile</h1><div class="card profile-head"><div class="avatar">${state.user.avatar}</div><div><h2>${state.user.name}</h2><span class="pill">@${state.user.username}</span>${authUser?`<p class="muted">GitHub: <a href="${escapeAttr(authUser.html_url)}" target="_blank" rel="noreferrer">@${escapeHtml(authUser.login)}</a></p>`:""}</div></div><div class="stats"><div class="stat"><strong>${state.user.games}</strong>Games</div><div class="stat"><strong>${state.user.wins}</strong>Wins</div><div class="stat"><strong>${state.user.quiz}</strong>Quiz Score</div><div class="stat"><strong>${state.user.points}</strong>Leaderboard</div></div><div class="card"><h2>🐾 Change avatar</h2><div class="actions">${state.avatars.map(a=>`<button class="secondary chooseAvatar" data-a="${a}">${a}</button>`).join("")}</div></div><div class="card"><h2>🔔 Notifications</h2>${state.notifications.map(n=>`<p>💗 ${n}</p>`).join("")}</div></section>`
};
function card(icon,title,desc,page,arg=""){return `<button class="card sectionCard" data-page="${page}" ${arg?`data-arg="${arg}"`:""}><div class="bigicon">${icon}</div><h2>${title}</h2><p class="muted">${desc}</p></button>`}
function medal(i){return ["🥇 TOP 1","🥈 TOP 2","🥉 TOP 3"][i]||"TOP "+(i+1)}
function bind(){
 const account=document.querySelector("#accountBtn"); if(account) account.onclick=()=> authUser ? showAccountModal() : showLoginModal();

 document.querySelectorAll("[data-page]").forEach(x=>x.onclick=()=>nav(x.dataset.page));
 const n=document.querySelector("#notifyBtn"); if(n)n.onclick=()=>showModal("<h2>🔔 Notifications</h2>"+state.notifications.map(x=>`<p>💗 ${x}</p>`).join(""));
 const m=document.querySelector("#menuBtn"); if(m)m.onclick=()=>showModal(`<h2>☰ Menu</h2>${["home","about","games","quiz","leaderboard","chat","profile"].map(p=>`<button class="secondary" style="width:100%;margin:5px 0" data-page="${p}">${p[0].toUpperCase()+p.slice(1)}</button>`).join("")}`);
 document.querySelectorAll(".lbrow").forEach(x=>x.onclick=()=>profileModal(x.dataset.profile));
 document.querySelectorAll(".chooseAvatar").forEach(x=>x.onclick=async()=>{state.user.avatar=x.dataset.a;try{const r=await fetch("/api/avatar",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({avatar:state.user.avatar})});if(r.ok){const d=await r.json();applyUser(d.user)}}catch(e){}toast("Avatar changed 🐾");app()});
 const live=document.querySelector("#editLive"); if(live)live.onclick=()=>{showModal(`<h2>😂 Update live message</h2><div class="field"><textarea id="liveInput" rows="4">${escapeHtml(state.live)}</textarea></div><button class="primary" id="saveLive">Save</button>`);document.querySelector("#saveLive").onclick=async()=>{const text=document.querySelector("#liveInput").value.trim();try{const r=await fetch("/api/live",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text})});if(!r.ok)throw new Error();state.live=text;closeModal();app()}catch(e){toast("Owner access required.")}}};
 const send=document.querySelector("#sendChat");if(send)send.onclick=sendChat;
 document.querySelectorAll(".reply").forEach(x=>x.onclick=()=>{document.querySelector("#chatInput").value="@"+x.dataset.name+" ";document.querySelector("#chatInput").focus()});
 const sq=document.querySelector("#startQuiz");if(sq)sq.onclick=startQuiz;
 document.querySelectorAll("[data-page='startGame']").forEach(x=>x.onclick=()=>startGame(x.dataset.arg));
}
async function sendChat(){const i=document.querySelector("#chatInput");if(!i.value.trim())return;if(!authUser){showLoginModal();return}try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:i.value.trim(),avatar:state.user.avatar})});if(!r.ok)throw new Error();const d=await r.json();state.chat.push(d.message);i.value="";app()}catch(e){toast("Could not send message.")}}
function startGame(type){const area=document.querySelector("#gameArea");if(!area)return;game={type,time:90,score:0};area.innerHTML=`<div class="gamebox"><div class="timer" id="gameTimer">1:30</div><h2>${type==="reaction"?"⚡ Reaction Rush":type==="moving"?"🎯 Moving Target":type==="memory"?"🧠 Memory Tiles":type==="dodge"?"🚧 Dodge":"🚫 Don't Click It"}</h2><p id="gameHint">Click the pink target to score.</p><div class="playfield" id="field"><button class="target" id="target"></button></div><h3>Game points: <span id="gameScore">0</span></h3><button class="secondary" id="endGame">End match</button></div>`;moveTarget();document.querySelector("#target").onclick=()=>{game.score++;document.querySelector("#gameScore").textContent=game.score;moveTarget()};document.querySelector("#endGame").onclick=endGame;game.interval=setInterval(()=>{game.time--;document.querySelector("#gameTimer").textContent=`${Math.floor(game.time/60)}:${String(game.time%60).padStart(2,"0")}`;if(game.time<=0)endGame()},1000)}
function moveTarget(){const f=document.querySelector("#field"),t=document.querySelector("#target");if(!f||!t)return;t.style.left=Math.random()*(f.clientWidth-80)+"px";t.style.top=Math.random()*(f.clientHeight-80)+"px"}
async function endGame(){if(!game)return;clearInterval(game.interval);const lb=Math.floor(game.score*.1*10)/10;state.user.games++;state.user.wins+=game.score>0?1:0;state.user.points+=lb;syncUser();try{const r=await fetch("/api/stats",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({games:1,wins:game.score>0?1:0,points:lb})});if(r.ok){const d=await r.json();if(d.user)applyUser(d.user)}}catch(e){}toast(`Match finished: ${game.score} points → +${lb} leaderboard`);game=null;document.querySelector("#gameArea").innerHTML=""}
const questions=[
["What is Aman’s username?","Ammuu",["Ammuu","AmanPro","AmmuCat","MineAman"]],
["What animal avatar does Aman use?","🐱",["🐱","🐼","🦊","🐸"]],
["What does Aman like to do with music?","Mix music",["Mix music","Only sing","Only dance","Never listen"]],
["What kind of movies does Aman watch?","All types",["Only horror","Only comedy","All types","Only anime"]],
["What is the website called?","AmanMineCircle",["AmanMineCircle","AmanWorld","MineCircle","AmmuuZone"]],
["What is the site's main color theme?","White + Pink",["Black + Red","White + Pink","Blue + Green","Yellow + Purple"]],
["How many questions are in a quiz match?","10",["5","8","10","20"]],
["How much of quiz/game score contributes to leaderboard?","10%",["5%","10%","25%","50%"]],
["Who can moderate the anonymous chat?","Aman / owner",["Everyone","Top 3","Random users","Aman / owner"]],
["Can users change their cute animal avatar?","Yes",["No","Only once","Yes","Only admin"]]
];
function startQuiz(){quiz={i:0,score:0};renderQuestion()}
function renderQuestion(){if(quiz.i>=questions.length)return endQuiz();const q=questions[quiz.i],area=document.querySelector("#quizArea");area.innerHTML=`<div class="quizbox"><span class="pill">Question ${quiz.i+1}/10</span><h2>${q[0]}</h2><div class="options">${q[2].map(a=>`<button data-answer="${escapeAttr(a)}">${a}</button>`).join("")}</div><p class="muted">⏱️ 3:00 allowed for this question</p></div>`;area.querySelectorAll(".options button").forEach(b=>b.onclick=()=>{if(b.dataset.answer===q[1])quiz.score++;quiz.i++;renderQuestion()})}
async function endQuiz(){state.user.quiz=quiz.score;const added=quiz.score/10;state.user.points+=added;syncUser();try{const r=await fetch("/api/stats",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({quiz:quiz.score,points:added})});if(r.ok){const d=await r.json();if(d.user)applyUser(d.user)}}catch(e){}document.querySelector("#quizArea").innerHTML=`<div class="card" style="text-align:center"><h2>🎉 Quiz complete!</h2><p>You scored <b>${quiz.score}/10</b>.</p><p>+${added} leaderboard points</p></div>`;toast("Quiz completed 🧠")}
function syncUser(){let x=state.leaderboard.find(u=>u.username===state.user.username);if(x)Object.assign(x,{...state.user})}
function applyUser(u){if(!u)return;state.user={...state.user,name:u.name,username:u.login,avatar:u.avatar,points:Number(u.points||0),games:Number(u.games||0),wins:Number(u.wins||0),quiz:Number(u.quiz||0)};syncUser()}
function profileModal(username){const u=state.leaderboard.find(x=>x.username===username);showModal(`<div class="profile-head"><div class="avatar">${u.avatar}</div><div><h2>${u.username}</h2><span class="pill">Public profile</span></div></div><div class="stats"><div class="stat"><strong>${u.games}</strong>Games</div><div class="stat"><strong>${u.wins}</strong>Wins</div><div class="stat"><strong>${u.quiz}</strong>Quiz Score</div><div class="stat"><strong>${u.points}</strong>⭐</div></div><button class="primary" id="closeP">Close</button>`);document.querySelector("#closeP").onclick=closeModal}
function showModal(x){document.querySelector("#modalBody").innerHTML=x;document.querySelector("#modal").classList.remove("hidden");document.querySelectorAll("#modalBody [data-page]").forEach(b=>b.onclick=()=>{closeModal();nav(b.dataset.page)})}
function closeModal(){document.querySelector("#modal").classList.add("hidden")}
function toast(x){const t=document.querySelector("#toast");t.textContent=x;t.style.cssText="position:fixed;bottom:22px;left:50%;transform:translateX(-50%);background:#8e356f;color:white;padding:12px 18px;border-radius:99px;z-index:80;box-shadow:0 8px 20px #0003";setTimeout(()=>t.textContent="",2500)}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function escapeAttr(s){return escapeHtml(s)}
async function loadAuth(){
 try{const r=await fetch('/api/bootstrap',{credentials:'same-origin'});const d=await r.json();authUser=d.user||null;state.live=d.live||state.live;state.chat=d.chat||[];state.leaderboard=d.leaderboard||state.leaderboard;state.notifications=d.notifications||[];if(authUser)applyUser(authUser);}catch(e){console.warn(e)}
 const params=new URLSearchParams(location.search); if(params.get('auth_error')) toast('GitHub login could not be completed.'); if(params.has('auth_error')||params.has('code')) history.replaceState({},'',location.pathname);
}
function updateAuthUI(){
 const b=document.querySelector('#accountBtn'); if(!b)return; b.textContent=authUser?'👤':'🔐'; b.title=authUser?`Signed in as ${authUser.login}`:'Sign in with GitHub';
}
function showLoginModal(){showModal(`<div class="auth-center"><div class="bigicon">🐙</div><h2>Sign in with GitHub</h2><p>Use your GitHub account to create your AmanMineCircle profile.</p><a class="primary auth-button" href="/auth/github">Continue with GitHub</a><p class="muted">Your GitHub password stays with GitHub.</p></div>`)}
function showAccountModal(){showModal(`<div class="profile-head"><img class="avatar-img" src="${escapeAttr(authUser.avatar)}" alt=""><div><h2>${escapeHtml(authUser.name)}</h2><span class="pill">@${escapeHtml(authUser.login)}</span></div></div><div class="card"><p>${escapeHtml(authUser.bio||'No GitHub bio')}</p><p class="muted">${authUser.public_repos} public repositories</p></div><div class="actions"><a class="secondary" href="${escapeAttr(authUser.html_url)}" target="_blank" rel="noreferrer">View GitHub</a><a class="secondary" href="/auth/logout">Log out</a></div>`)}
window.addEventListener("load",async()=>{setTimeout(()=>document.querySelector("#loading").style.opacity=0,350);setTimeout(()=>document.querySelector("#loading").remove(),850);await loadAuth();app()});
